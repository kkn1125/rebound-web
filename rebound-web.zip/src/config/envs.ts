export const DEPLOY_URL = process.env.DEPLOY_URL as string;
export const BRAND = process.env.BRAND as string;
